package com.iiht.tweetapp.config;

public class AppConfigs {
	public final static String applicationID = "StorageDemo";
    public final static String bootstrapServers = "localhost:9092";
    public final static String topicName = "userauth";
    
}
